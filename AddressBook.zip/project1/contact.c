/*Documentation
Name : Sokkalingam Ajith M
Date : 19/10/2024
Des  : AddressBook Project
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#include <ctype.h>

int findMobile(AddressBook *addressBook, int *arr, int count) {
    char num[20]; //create the char array
    printf("Enter the mobile number to find: ");
    scanf("%s", num); //read user input

    for (int i = 0; i < count; i++) { //Iterating the loop
        if (strcmp(addressBook->contacts[arr[i]].phone, num) == 0) { //To check the  Mobile number present or not
            return arr[i];  //return the index position
        }
    }

    printf("No contact found in the mobile number.\n");
    return -1;  
}

int findName(AddressBook *addressBook, const char *name) {
    for (int i = 0; i < addressBook->contactCount; i++) { //Iterating the loop
        if (strcasecmp(addressBook->contacts[i].name, name) == 0) { //To check the Name is already prsent or not
            return i; //return the index position
        }
    }
    return -1;
}

int findPhone(AddressBook *addressBook, const char *phone) {
    for (int i = 0; i < addressBook->contactCount; i++) { //Iterating the loop
        if (strcmp(addressBook->contacts[i].phone, phone) == 0) { //to check the number is already  present or not
            return i;  //return the index position
        }
    }
    return -1;
}

int findEmail(AddressBook *addressBook, const char *email) {
    for (int i = 0; i < addressBook->contactCount; i++) { //Iterating the loop
        if (strcmp(addressBook->contacts[i].email, email) == 0) { //To check the email is already present or not
            return i;
        }
    }
    return -1;
}

int isValidName(const char *name) {
    int n =  strlen(name); //To find the length of string
    for (int i = 0; i < n; i++) { //Iterating the loop
        if (!isalpha(name[i]) && name[i] != ' ')   { //To check the valid name or not
            return -1;
        }
    }
    return 0;
}

int isValidnum(const char *phone){

      if(strlen(phone)!= 10){ //To check the length of number
       return -1;
      }
      for(int i = 0; i < 10 ;i++){ //Iterating the loop
      if(!isdigit(phone[i]) && phone[i] != ' ' && !isalpha(phone[i])){ //To check the number is valid or not
          return -1;
       }
      }
     return 0;
}

int isValidmail(const char *email) {
    if(*email == '\0' || *email == '@'){
        return -1;
  } 
    for(int i = 0; i < strlen(email);i++){ //Itarating the loop and to check the valid email
     if(email[i] == '@'){
   
        if(strstr(email,".com")){

            if(email[i+1] != '.' || email[i+1]!= ' '){
                return 0;
        }
      }
    }
}
    return -1;

}

void listContacts(AddressBook *addressBook) 
{ 
  printf("Name\t      Mobile Number\t  Email id\n\n");
    for(int i = 0; i < addressBook->contactCount;i++){ //Iterating the loop
                    if(strlen(addressBook->contacts[i].name) <= 7){ 
		    printf("%s\t\t%s\t%s\n\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                                      //To display the name mobile number email
               }
           else
           {
           printf("%s\t%s\t%s\n\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);

         } 
} 
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
   // populateAddressBook(addressBook);
    loadContactsFromFile(addressBook);
    // Load contacts from file during initialization (After files)

}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
            if (addressBook->contactCount >= 100) { //To check count less than 100
        printf("Address book is full. Cannot add more contacts.\n"); 
        return;
     }

    Contact newContact; //create a structure variable

      
    int validName = 0; //create a variable
    do {
        printf("Enter name: ");
        getchar();
        scanf("%[^\n]", newContact.name);  //read a user input
        if (isValidName(newContact.name) == 0) { //To check the valid name
            validName = 1; 
        }
        else {
            printf("Invalid name.\n");
        }
 
    } while (!validName); //the loop run upto the condition false


   
        int validNum = 0; //create a variable
    do {
        printf("Enter phone number : ");
        getchar(); 
        scanf("%s", newContact.phone); //read user input
        if(findPhone(addressBook,newContact.phone) == -1){ //To check the the num is already present or not
        if (isValidnum(newContact.phone) == 0) { //the check num is valid or not
            validNum = 1; 
        } else {
            printf("Invalid number.\n");
        }
        } else{
            printf("The Number is already exist. Try again!\n");
}
    } while (!validNum); //the loop run upto the condition false



       int validemail = 0;
    do {
        printf("Enter email: ");
        getchar();
        scanf("%s",newContact.email); //read the user input
        if(findEmail(addressBook,newContact.email) == -1){ //To check the email is already present or not
        if (isValidmail(newContact.email) == 0) { //To check mail is valid or not
            validemail = 1;
        } else {
            printf("Invalid Email\n");
        }
     }else{
         printf("The email is already exist. Try again!\n");
}
    } while (!validemail); //upto run the loop condition flase
      

    addressBook->contacts[addressBook->contactCount++] = newContact; //add the data to the structure and increment the contactcount
    printf("Contact added successfully.\n");
}

void searchContact(AddressBook *addressBook) {
    int choice;
    char searchInput[50]; //create a char array and create the variables
    int value = -1;


    printf("Search Contact by:\n");
    printf("1. Name\n");
    printf("2. Mobile Number\n");
    printf("3. Email\n");
    printf("Enter your choice (1-3): ");
    scanf("%d", &choice); //read the user input
    getchar();  

     switch (choice) { //user choice
        case 1: {
            printf("Enter name: ");
            scanf("%[^\n]", searchInput); //user input
            int count = 0; //assign count is 0
            int arr[50];  //create the array

            
            for (int i = 0; i < addressBook->contactCount; i++) { //Iterating the loop
                if (strcasecmp(addressBook->contacts[i].name, searchInput) == 0) { //To check the name already present or not
                    arr[count++] = i;  //index position add to array
                }
            }

            if (count == 0) { //count 0 means no count found
                printf("No contacts found with the name: %s\n", searchInput);
            } else if (count == 1) {
                value = arr[0];  //assign the index position to value
            } else {
               
                printf("Multiple contacts found with the name '%s':\n", searchInput);
                for (int i = 0; i < count; i++) {
                    printf("%d. Name: %s, Phone: %s, Email: %s\n", i + 1,
                           addressBook->contacts[arr[i]].name,
                           addressBook->contacts[arr[i]].phone, //display the conatct details
                           addressBook->contacts[arr[i]].email);
                }

                
                value = findMobile(addressBook, arr, count); //call the function and ask mobile num
            }
            break;
        }
        
        case 2:
           
            printf("Enter mobile number: ");
            scanf("%s", searchInput); //read the user input
            value = findPhone(addressBook, searchInput); //function calling and assign the index to value
            break;
        
        case 3:
           
            printf("Enter email: ");
            scanf("%s", searchInput); //read the user input
            value = findEmail(addressBook, searchInput); //function calling and assign the index to value
            break;
        
        default:
            printf("Invalid choice. Please select 1, 2, or 3.\n");
            return;
    }

    if (value != -1) {
        printf("Contact found:\n");
        printf("Name: %s\n", addressBook->contacts[value].name);  //display the contact details
        printf("Phone: %s\n", addressBook->contacts[value].phone);
        printf("Email: %s\n", addressBook->contacts[value].email);
    } else {
        printf("Contact not found.\n");
    }
}


void editContact(AddressBook *addressBook) {
    char searchInput[50]; //create the char array
    int value = -1;

    
    printf("Enter the name of the contact to edit: ");
    getchar(); //newline char
    scanf("%[^\n]", searchInput); //read the user input
    
    value = findName(addressBook, searchInput); //function calling and assign the index to value
    
    if (value == -1) {
        printf("Contact not found with the name: %s\n", searchInput);
        return;
    }
    
    printf("Contact found:\n");
    printf("Name: %s\n", addressBook->contacts[value].name);
    printf("Phone: %s\n", addressBook->contacts[value].phone); //display the contact 
    printf("Email: %s\n", addressBook->contacts[value].email);
    
    int editChoice;
    printf("What do you want to edit?\n");
    printf("1. Name\n");
    printf("2. Phone Number\n");
    printf("3. Email\n");
    printf("Enter your choice (1-3): ");
    scanf("%d", &editChoice); //read the user input
    getchar(); 

    switch (editChoice) {
        case 1: {  
            char newName[50]; //create the char array
            int validName = 0;
            
            do {
                printf("Enter new name: ");
                scanf("%[^\n]", newName); //read the user input
                if (isValidName(newName) == 0) { //To check the name is valid or not
                    validName = 1;
                } else {
                    printf("Invalid name. Please try again.\n");
                }
            } while (!validName); //the loop run upto condition false

            strcpy(addressBook->contacts[value].name, newName); //copy function use to copy the new name
            printf("Name updated successfully.\n");
            break;
        }

        case 2: {  
            char newPhone[20]; //create char array
            int validNum = 0;
            
            do {
                printf("Enter new phone number: ");
                scanf("%s", newPhone); //user input
                
                if (findPhone(addressBook, newPhone) == -1) { //to check the num is already present or not
                    if (isValidnum(newPhone) == 0) { //to check the num is valid or not
                        validNum = 1;
                    } else {
                        printf("Invalid phone number. Please try again.\n");
                    }
                } else {
                    printf("Phone number already exists. Please try again.\n");
                }
            } while (!validNum); //the loop run upto condition false

            strcpy(addressBook->contacts[value].phone, newPhone); //copy function use to copy the number
            printf("Phone number updated successfully.\n");
            break;
        }

        case 3: {  
            char newEmail[50]; //create the char array
            int validEmail = 0;
            
            do {
                printf("Enter new email: ");
                scanf("%s", newEmail); //read the user input
                
                if (findEmail(addressBook, newEmail) == -1) { //To check the mail is already present or not
                    if (isValidmail(newEmail) == 0) { //To check the mail is valid or not
                        validEmail = 1;
                    } else {
                        printf("Invalid email. Please try again.\n");
                    }
                } else {
                    printf("Email already exists. Please try again.\n");
                }
            } while (!validEmail); //the loop run upto condition false

            strcpy(addressBook->contacts[value].email, newEmail); //copy function use to copy the mail
            printf("Email updated successfully.\n");
            break;
        }

        default:
            printf("Invalid choice. No changes made.\n");
            break;
    }
}

void deleteContact(AddressBook *addressBook) {
    int choice;
    char searchInput[50]; //create char array
    int value = -1;

    printf("Delete Contact by:\n");
    printf("1. Name\n");
    printf("2. Mobile Number\n");
    printf("3. Email\n");
    printf("Enter your choice (1-3): ");
    scanf("%d", &choice); //read the user input
    getchar(); //newline char

    switch (choice) {
        case 1: { 
            printf("Enter the name of the contact to delete: ");
            scanf("%[^\n]", searchInput); //read the user input
            getchar();

            
            int count = 0;
            int arr[100]; 
            for (int i = 0; i < addressBook->contactCount; i++) {
                if (strcasecmp(addressBook->contacts[i].name, searchInput) == 0) { //To check the name is alraedy present or ot
                    arr[count++] = i; //assign the index postion value to array
                }
            }

            if (count == 0) {
                printf("No contact found with the name: %s\n", searchInput);
                return;
            } else if (count == 1) {
                value = arr[0];
            } else {
                printf("Multiple contacts found with the name '%s':\n", searchInput);
                for (int i = 0; i < count; i++) {
                    printf("%d. Name: %s, Phone: %s, Email: %s\n", i + 1,
                           addressBook->contacts[arr[i]].name,
                           addressBook->contacts[arr[i]].phone, //display the contact
                           addressBook->contacts[arr[i]].email);
                }

                
                char mobileInput[20]; //create char array
                printf("Enter the mobile number of the contact you want to delete: ");
                scanf("%s", mobileInput); //read the number to user
                getchar();

                
                int found = 0;
                for (int i = 0; i < count; i++) {
                    if (strcmp(addressBook->contacts[arr[i]].phone, mobileInput) == 0) { //To check the number is present or not
                        value = arr[i]; 
                        found = 1;
                        break;
                    }
                }

                if (!found) {
                    printf("No contact found with the name '%s' and mobile number '%s'.\n", searchInput, mobileInput);
                    return;
                }
            }
            break;
        }

        case 2: { 
            printf("Enter the mobile number of the contact to delete: ");
            scanf("%s", searchInput); //read the number to user
            getchar();

            value = findPhone(addressBook, searchInput); //To check the num is present or not assign the index postion to value
            if (value == -1) {
                printf("No contact found with the mobile number: %s\n", searchInput);
                return;
            }
            break;
        }

        case 3: { 
            printf("Enter the email of the contact to delete: ");
            scanf("%s", searchInput); //read the mail to useer
            getchar();

            value = findEmail(addressBook, searchInput); //To check the mail is present or not and aasign the index position to value
            if (value == -1) {
                printf("No contact found with the email: %s\n", searchInput);
                return;
            }
            break;
        }

        default:
            printf("Invalid choice. Please select 1, 2, or 3.\n");
            return;
    }

   
    if (value != -1) {
        printf("\nContact found:\n");
        printf("Name: %s\n", addressBook->contacts[value].name); //display the contact
        printf("Phone: %s\n", addressBook->contacts[value].phone);
        printf("Email: %s\n", addressBook->contacts[value].email);

        char ch; //create a variable
        printf("Are you sure you want to delete this contact? (y/n): ");
        scanf(" %c", &ch); //raed a user input
        getchar();

        if (ch == 'y' || ch == 'Y') { //if condition true
        
            for (int i = value; i < addressBook->contactCount - 1; i++) { //Iterating the loop
                addressBook->contacts[i] = addressBook->contacts[i + 1];  //the next contact add to previous contact
            }
            addressBook->contactCount--; //decrement the contactcount also

            printf("Contact deleted successfully.\n");
        } else {
            printf("Contact deletion canceled.\n");
        }
    }
}

   
