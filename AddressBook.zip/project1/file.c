/*Documentation
Name : Sokkalingam Ajith M
Date : 19/10/2024
Des  : AddressBook project
*/
#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) {
    FILE *fp = fopen("add.csv", "w"); //create the file pointer and write the data
    if (fp == NULL) {
        perror("Error ");
        return;
    }
    
    fprintf(fp, "%d\n", addressBook->contactCount); //print the contactcount from the file

    for (int i = 0; i < addressBook->contactCount; i++) { //Iterating the loop upto contactcount

        fprintf(fp, "%s,", addressBook->contacts[i].name); 
        fprintf(fp, "%s,", addressBook->contacts[i].phone);
        fprintf(fp, "%s\n", addressBook->contacts[i].email);
    }

    fclose(fp); //close the file poniter
}

void loadContactsFromFile(AddressBook *addressBook) {
    FILE *fp = fopen("add.csv", "r"); //create the file pointer and read the data
    if (fp == NULL) {
        perror("Error ");
        return;
    }
    fscanf(fp, "%d\n", &addressBook->contactCount); //read the contactcount from the file

    for (int i = 0; i < addressBook->contactCount; i++) { //Iterating the loop upto contactcount
   
        fscanf(fp, "%[^,],%[^,],%[^\n]\n", 
          addressBook->contacts[i].name,
          addressBook->contacts[i].phone,
          addressBook->contacts[i].email);
    }

    fclose(fp); //close the filr pointer
}

